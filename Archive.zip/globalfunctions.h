#ifndef GLOBALFUNCTIONS_H
#define GLOBALFUNCTIONS_H

#include <QString>
#include <QDebug>

double evaluateExpression(QString f);

#endif // GLOBALFUNCTIONS_H
